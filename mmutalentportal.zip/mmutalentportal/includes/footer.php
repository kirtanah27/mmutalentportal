<footer>
    <p>&copy; <?= date('Y') ?> MMU Talent Showcase Portal. All rights reserved.</p>
</footer>

</body>
</html>
